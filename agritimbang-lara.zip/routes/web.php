<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Public Pages
|--------------------------------------------------------------------------
| Authentication is handled by our REST API using Sanctum bearer tokens.
| Blade routes only serve frontend pages.
*/

Route::redirect('/', '/login')->name('home');

Route::view('/login', 'auth.login')
    ->name('login');

Route::view('/register', 'auth.register')
    ->name('register');

Route::view('/verify-email', 'auth.verify-email')
    ->name('verification.notice');

Route::view('/forgot-password', 'auth.forgot-password')
    ->name('password.request');


Route::get('/reset-password/{token}', function (string $token) {
    return view('auth.reset-password', [
        'token' => $token,
        'email' => request()->query('email', ''),
    ]);
})->name('password.reset');

/*
|--------------------------------------------------------------------------
| Application Pages
|--------------------------------------------------------------------------
| These routes serve Blade shells only.
| Authentication is verified through /api/auth/me.
| Sensitive data must never be embedded in these views.
*/

Route::view('/dashboard', 'dashboard.index')
    ->name('dashboard');

Route::view('/gis', 'gis.index')
    ->name('gis.index');


Route::view('/account-verification', 'auth.account-verification')
    ->name('account.verification');

Route::view('/livestock/monitoring', 'livestock.monitoring')
    ->name('livestock.monitoring');

Route::view('/analytics/prices', 'analytics.prices')
    ->name('analytics.prices');


Route::view('/analytics/transactions', 'analytics.transactions')
    ->name('analytics.transactions');


Route::view('/analytics/valuations', 'analytics.valuations')
    ->name('analytics.valuations');

Route::view('/farmers', 'farmers.index')
    ->name('farmers.index');


Route::get('/farmers/{farmer}', function (string $farmer) {
    return view('farmers.show', compact('farmer'));
})->name('farmers.show');


Route::view('/livestock', 'livestock.index')
    ->name('livestock.index');

Route::view('/auctions', 'auctions.farmer')
    ->name('farmer.auctions.index');

Route::view('/auction-follow-ups', 'auctions.follow-ups')->name('farmer.auction-follow-ups');
Route::view('/lgu/auction-follow-ups', 'auctions.follow-ups')->name('lgu.auction-follow-ups');

Route::get('/auctions/{schedule}', function (string $schedule) {
    return view('auctions.schedule', ['scheduleId' => $schedule]);
})->name('farmer.auctions.show');

Route::get('/auctions/{schedule}/register', function (string $schedule) {
    return view('auctions.register', ['scheduleId' => $schedule]);
})->name('farmer.auctions.register');

Route::view('/lgu/auction-schedules', 'lgu.auction-schedules')
    ->name('lgu.auction-schedules.index');

Route::get('/lgu/auction-schedules/{schedule}/registrations', function (string $schedule) {
    return view('lgu.auction-registrations', ['scheduleId' => $schedule]);
})->name('lgu.auction-schedules.registrations');

Route::view('/admin/lgu-authorities', 'users.authorities')
    ->name('admin.lgu-authorities.index');

Route::view('/users', 'users.index')
    ->name('admin.users.index');

Route::view('/lgu/encoders', 'lgu.encoders.index')
    ->name('lgu.encoders.index');

Route::view('/livestock/register', 'livestock.create')
    ->name('farmer.livestock.create');

Route::get('/livestock/{livestock}/edit', function (string $livestock) {
    return view('livestock.edit', ['livestockId' => $livestock]);
})->name('livestock.edit');

Route::get('/livestock/{livestock}', function (string $livestock) {
    return view('livestock.show', ['livestockId' => $livestock]);
})->name('livestock.show');

Route::view('/calculator', 'calculator.index')
    ->name('calculator.index');


Route::view('/prices', 'prices.index')
    ->name('prices.index');

Route::view('/prices/create', 'prices.form')
    ->name('prices.create');

Route::view('/prices/{priceReference}/edit', 'prices.form')
    ->name('prices.edit');

Route::view('/prices/submissions', 'prices.submissions')
    ->name('prices.submissions');

Route::view('/prices/approvals', 'prices.approvals')
    ->name('prices.approvals');

Route::view('/prices/approvals/{priceReference}', 'prices.review')
    ->name('prices.review');

Route::view('/analytics/forecast', 'analytics.forecast')
    ->name('analytics.forecast');

Route::get('/buyer/confirm/{token}', function (string $token) {
    return view('buyer.confirmation', [
        'token' => $token,
    ]);
})
    ->where('token', '[a-fA-F0-9]{64}')
    ->middleware('throttle:30,1')
    ->name('buyer.confirmation.show');

Route::view('/transactions', 'transactions.index')->name('transactions.index');

Route::view('/transactions/create', 'transactions.create')
    ->name('transactions.create');


Route::view(
    '/transactions/review',
    'transactions.lgu-verification'
);

Route::view(
    '/transactions/disputes',
    'transactions.dispute-resolution'
);

Route::view('/audit-logs', 'audit-logs.index')->name('audit-logs.index');

Route::view('/admin/locations', 'admin.locations')
    ->name('admin.locations');

Route::view(
    '/admin/species-breeds',
    'admin.species-breeds'
);

Route::view(
    '/lgu/auction-houses',
    'lgu.auction-houses'
);

Route::view(
    '/lgu/gis-monitoring',
    'lgu.gis-monitoring'
)->name('lgu.gis-monitoring');

Route::view(
    '/lgu/farmer-verifications',
    'lgu.farmer-verifications'
)->name('lgu.farmer-verifications');

Route::view('/profile', 'profile.index')
    ->name('profile.index');

Route::view('/transactions/assist', 'transactions.assist')
    ->name('transactions.assist');

Route::view('/transactions/history', 'transactions.encoder-history')
    ->name('transactions.encoder-history');

Route::view('/lgu/transactions/history', 'transactions.encoder-history')
    ->name('lgu.transactions.history');

Route::view('/admin/transactions/history', 'transactions.encoder-history')
    ->name('admin.transactions.history');

Route::view('/reports', 'reports.index')
    ->name('reports.index');