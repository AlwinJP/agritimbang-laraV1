AgriTimbang - Authority Transaction Verification Fix Overlay

Copy the folders in this ZIP into the root of your current AgriTimbang Laravel project and overwrite matching files.

Fixes:
- Normalizes eligible legacy pending transactions before Authority approval/rejection, including encoder and auction-house submissions.
- Includes auction sales identified by transaction_type, auction_schedule_id, or auction_house source, even when older records have incomplete transaction_type values.
- Keeps auction sales identifiable in the Authority review list and details.
- Displays Livestock & Valuation Details as a horizontally scrollable table with one row per livestock item.
- Prevents the approve/reject controls from triggering unintended default browser behavior.

After copying, run:
  php artisan optimize:clear
  npm run build

No database migration is included or required for these code changes.

If the browser still shows the old screen, hard-refresh the page after npm run build.
