<?php

namespace App\Services;

use App\Models\Transaction;
use App\Models\AuctionRegistration;
use App\Models\AuctionSchedule;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class LguTransactionVerificationService
{
    public function approve(User $officer, string $transactionId): Transaction
    {
        return $this->process($officer, $transactionId, true);
    }

    public function reject(
        User $officer,
        string $transactionId,
        string $reason
    ): Transaction {
        $reason = trim($reason);

        if (mb_strlen($reason) < 5 || mb_strlen($reason) > 2000) {
            throw ValidationException::withMessages([
                'reason' => 'A rejection reason between 5 and 2000 characters is required.',
            ]);
        }

        return $this->process($officer, $transactionId, false, $reason);
    }

    private function process(
        User $officer,
        string $transactionId,
        bool $approved,
        ?string $reason = null
    ): Transaction {
        return DB::transaction(function () use ($officer, $transactionId, $approved, $reason) {
            $transaction = Transaction::query()
                ->whereKey($transactionId)
                ->lockForUpdate()
                ->firstOrFail();


            $this->authorizeOfficer($officer, $transaction);

            // Older confirmed farmer transactions may still carry the legacy
            // "pending" status. Normalize them at decision time only after a
            // confirmed buyer acknowledgement exists.
            $legacyPendingIsReviewable =
                in_array($transaction->source, ['lgu_encoder', 'auction_house'], true) ||
                $transaction->buyerConfirmations()
                    ->where('status', 'confirmed')
                    ->exists() ||
                $transaction->statusLogs()
                    ->where('to_status', 'pending_lgu_verification')
                    ->exists();

            if ($transaction->status === 'pending' && $legacyPendingIsReviewable) {
                $transaction->update(['status' => 'pending_lgu_verification']);
                $transaction->statusLogs()->create([
                    'from_status' => 'pending',
                    'to_status' => 'pending_lgu_verification',
                    'actor_type' => 'system',
                    'actor_user_id' => null,
                    'remarks' => 'Legacy eligible transaction moved into the LGU review queue before the Authority decision.',
                ]);
                $transaction->refresh();
            }

            $hasActiveDispute = $transaction->disputes()
                ->whereIn('status', ['open', 'under_review'])
                ->exists();

            if ($hasActiveDispute) {
                throw ValidationException::withMessages([
                    'dispute' => 'This transaction has an unresolved dispute. The LGU must resolve it before verification can proceed.',
                ]);
            }

            $this->validateTransaction($transaction);


            $items = $transaction->items()
                ->orderBy('livestock_id')
                ->get();

            if ($items->isEmpty()) {
                throw ValidationException::withMessages([
                    'items' => 'Transaction must contain livestock.',
                ]);
            }

            if ($items->pluck('livestock_id')->unique()->count() !== $items->count()) {
                throw ValidationException::withMessages([
                    'items' => 'Duplicate livestock records are not allowed.',
                ]);
            }

            foreach ($items as $item) {
                $livestock = $item->livestock()
                    ->lockForUpdate()
                    ->firstOrFail();

                if (
                    $livestock->farmer_id !== $transaction->farmer_id ||
                    $livestock->status !== 'in_transaction'
                ) {
                    throw ValidationException::withMessages([
                        'items' => 'Livestock ownership or reservation is inconsistent.',
                    ]);
                }

                if (!$approved) {
                    $hasOtherActiveSale = $livestock->transactionItems()
                        ->whereHas('transaction', function ($query) use ($transaction) {
                            $query->where('transactions.id', '!=', $transaction->id)
                                ->whereIn('transactions.status', [
                                    'pending',
                                    'pending_lgu_verification',
                                ]);
                        })
                        ->exists();

                    if ($hasOtherActiveSale) {
                        throw ValidationException::withMessages([
                            'items' => 'Livestock belongs to another active transaction.',
                        ]);
                    }
                }

                $livestock->update([
                    'status' => $approved ? 'sold' : 'available',
                ]);

                if ($transaction->auction_schedule_id) {
                    $registration = AuctionRegistration::query()
                        ->where('auction_schedule_id', $transaction->auction_schedule_id)
                        ->where('livestock_id', $livestock->id)
                        ->where('farmer_id', $transaction->farmer_id)
                        ->lockForUpdate()
                        ->first();

                    if ($registration) {
                        $schedule = AuctionSchedule::query()->find($transaction->auction_schedule_id);
                        if ($approved) {
                            $registration->update([
                                'status' => 'completed',
                                'active_livestock_id' => null,
                                'remarks' => trim(($registration->remarks ? $registration->remarks . "\n" : '') . 'Auction sale verified by LGU Authority.'),
                            ]);
                        } elseif ($schedule && $schedule->status === 'ongoing') {
                            $registration->update([
                                'status' => 'registered',
                                'active_livestock_id' => $livestock->id,
                                'remarks' => trim(($registration->remarks ? $registration->remarks . "\n" : '') . 'Auction sale was rejected; livestock remains registered because the event is still ongoing.'),
                            ]);
                        } else {
                            $registration->update([
                                'status' => 'rejected',
                                'active_livestock_id' => null,
                                'remarks' => trim(($registration->remarks ? $registration->remarks . "\n" : '') . 'Auction sale was rejected after the event closed; registration was not reopened.'),
                            ]);
                        }
                    }
                }
            }

            $newStatus = $approved ? 'verified' : 'rejected';

            $transaction->update([
                'status' => $newStatus,
                'verified_by' => $officer->id,
                'verified_at' => now(),
                'remarks' => $approved
                    ? 'Verified by LGU officer.'
                    : $reason,
            ]);

            $transaction->statusLogs()->create([
                'from_status' => 'pending_lgu_verification',
                'to_status' => $newStatus,
                'actor_type' => 'lgu',
                'actor_user_id' => $officer->id,
                'remarks' => $approved
                    ? 'LGU officer approved the transaction.'
                    : $reason,
            ]);

            return $transaction->fresh(['items']);
        }, 3);
    }


    private function authorizeOfficer(
        User $officer,
        Transaction $transaction
    ): void {
        $profile = $officer->lguOfficerProfile;

        abort_unless(
            $profile !== null &&
            $officer->status === 'active' &&
            $officer->verification_status === 'verified' &&
            $officer->roles()
                ->where('slug', 'lgu_authority')
                ->exists(),
            403,
            'An active, verified LGU officer is required.'
        );

        $transactionMunicipalityId = $transaction->municipality_id;
        $farmerMunicipalityId = $transaction->farmer?->municipality_id;

        // Some older farmer-created records relied on the farmer profile for
        // municipality scope. Safely backfill a missing transaction municipality
        // from that profile before applying the same municipality boundary.
        if (!$transactionMunicipalityId && $farmerMunicipalityId) {
            $transaction->forceFill([
                'municipality_id' => $farmerMunicipalityId,
            ])->save();
            $transactionMunicipalityId = $farmerMunicipalityId;
        }

        abort_unless(
            (string) $profile->municipality_id === (string) $transactionMunicipalityId,
            403,
            'Transaction is outside your municipality.'
        );

        abort_if(
            $transaction->encoded_by === $officer->id,
            403,
            'You cannot verify your own encoded transaction.'
        );
    }



    private function validateTransaction(Transaction $transaction): void
    {
        if ($transaction->status !== 'pending_lgu_verification') {
            throw ValidationException::withMessages([
                'status' => 'Transaction is not awaiting LGU verification.',
            ]);
        }

        $farmer = $transaction->farmer;

        if (!$farmer) {
            throw ValidationException::withMessages([
                'farmer' => 'A registered farmer is required.',
            ]);
        }

        if (
            (string) $farmer->municipality_id !==
            (string) $transaction->municipality_id
        ) {
            throw ValidationException::withMessages([
                'farmer' => 'Farmer municipality does not match the transaction.',
            ]);
        }

        /*
        |--------------------------------------------------------------------------
        | FARMER-CREATED TRANSACTION
        |--------------------------------------------------------------------------
        | Buyer confirmation is mandatory.
        */

        if ($transaction->source === 'farmer') {
            if (
                !$transaction->buyerConfirmations()
                    ->where('status', 'confirmed')
                    ->exists()
            ) {
                throw ValidationException::withMessages([
                    'buyer_confirmation' =>
                        'Buyer confirmation is required.',
                ]);
            }

            return;
        }

        /*
        |--------------------------------------------------------------------------
        | LGU ENCODER TRANSACTION
        |--------------------------------------------------------------------------
        | No buyer confirmation required.
        | Must be encoded by an authorized LGU Encoder.
        */

        if ($transaction->source === 'lgu_encoder') {
            if (!$transaction->encoded_by) {
                throw ValidationException::withMessages([
                    'encoder' => 'An LGU Encoder is required.',
                ]);
            }

            $encoder = User::query()
                ->with('lguOfficerProfile')
                ->find($transaction->encoded_by);

            if (
                !$encoder ||
                !$encoder->roles()
                    ->where('slug', 'lgu_encoder')
                    ->exists()
            ) {
                throw ValidationException::withMessages([
                    'encoder' =>
                        'Transaction was not created by an LGU Encoder.',
                ]);
            }

            if (
                (string) $encoder->lguOfficerProfile?->municipality_id !==
                (string) $transaction->municipality_id
            ) {
                throw ValidationException::withMessages([
                    'encoder' =>
                        'Encoder municipality does not match the transaction.',
                ]);
            }

            return;
        }

        /*
        |--------------------------------------------------------------------------
        | AUCTION HOUSE TRANSACTION
        |--------------------------------------------------------------------------
        | Existing acknowledgement workflow.
        */

        if ($transaction->source === 'auction_house') {
            $validHouse = $transaction->auctionHouse()
                ->where(
                    'municipality_id',
                    $transaction->municipality_id
                )
                ->exists();

            if (
                !$validHouse ||
                !$transaction->encoded_by ||
                $transaction->buyer_confirmation_method !== 'in_person' ||
                !filled($transaction->acknowledgement_reference)
            ) {
                throw ValidationException::withMessages([
                    'acknowledgement' =>
                        'Valid auction-house acknowledgement is required.',
                ]);
            }

            $encoderWasAssigned = DB::table(
                'auction_house_encoder_assignments'
            )
                ->where(
                    'auction_house_id',
                    $transaction->auction_house_id
                )
                ->where(
                    'user_id',
                    $transaction->encoded_by
                )
                ->where(
                    'created_at',
                    '<=',
                    $transaction->created_at
                )
                ->exists();

            if (!$encoderWasAssigned) {
                throw ValidationException::withMessages([
                    'encoder' =>
                        'Transaction encoder has no valid assignment record.',
                ]);
            }

            return;
        }

        throw ValidationException::withMessages([
            'source' => 'Unsupported transaction source.',
        ]);
    }

}
