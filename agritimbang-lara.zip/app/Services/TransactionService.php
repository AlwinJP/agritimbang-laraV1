<?php

namespace App\Services;

use App\Jobs\SendBuyerConfirmationSms;
use App\Models\FarmerProfile;
use App\Models\Barangay;
use App\Models\AuctionRegistration;
use App\Models\LivestockRecord;
use App\Models\Transaction;
use App\Models\User;
use App\Models\Valuation;
use App\Notifications\SystemAlertNotification;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class TransactionService
{
    private const ACTIVE_STATUSES = [
        'pending',
        'pending_lgu_verification',
        'verified',
    ];

    /*
    |--------------------------------------------------------------------------
    | FARMER TRANSACTIONS
    |--------------------------------------------------------------------------
    */

    public function createDraft(
        User $user,
        array $data
    ): Transaction {
        $farmer = $this->verifiedFarmer($user);

        return $this->createTransactionDraft(
            $user,
            $farmer,
            $data,
            'farmer'
        );
    }

    public function submit(
        User $user,
        string $transactionId,
        BuyerConfirmationService $confirmationService
    ): Transaction {
        $farmer = $this->verifiedFarmer($user);

        return $this->submitTransactionDraft(
            $user,
            $farmer,
            $transactionId,
            $confirmationService,
            'farmer'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | LGU ENCODER TRANSACTIONS
    |--------------------------------------------------------------------------
    */

    public function createEncoderDraft(
        User $encoder,
        array $data
    ): Transaction {
        $this->assertEncoder($encoder);

        $farmer = FarmerProfile::query()
            ->with('user')
            ->findOrFail($data['farmer_id']);

        $this->assertEncoderCanAccessFarmer(
            $encoder,
            $farmer
        );

        return $this->createTransactionDraft(
            $encoder,
            $farmer,
            $data,
            'lgu_encoder'
        );
    }


    public function submitEncoderDraft(
        User $encoder,
        string $transactionId,
        BuyerConfirmationService $confirmationService
    ): Transaction {
        $this->assertEncoder($encoder);

        return DB::transaction(function () use ($encoder, $transactionId) {
            $transaction = Transaction::query()
                ->whereKey($transactionId)
                ->lockForUpdate()
                ->firstOrFail();

            // Only the encoder who created the draft can submit it.
            if (
                (string) $transaction->encoded_by !==
                (string) $encoder->id
            ) {
                abort(403, 'You cannot submit this transaction.');
            }

            // Prevent submitting an already processed transaction.
            if ($transaction->status !== 'draft') {
                throw ValidationException::withMessages([
                    'status' => 'Only draft transactions can be submitted.',
                ]);
            }

            $farmer = FarmerProfile::query()
                ->with('user')
                ->findOrFail($transaction->farmer_id);

            // Verify that the farmer is still authorized
            // and belongs to the encoder's municipality.
            $this->assertEncoderCanAccessFarmer(
                $encoder,
                $farmer
            );

            if (
                (string) $transaction->municipality_id !==
                (string) $farmer->municipality_id ||
                (string) $transaction->barangay_id !==
                (string) $farmer->barangay_id
            ) {
                throw ValidationException::withMessages([
                    'farmer' => 'Transaction location no longer matches the farmer.',
                ]);
            }

            $items = $transaction->items()
                ->orderBy('livestock_id')
                ->get();

            if ($items->isEmpty()) {
                throw ValidationException::withMessages([
                    'items' => 'Transaction has no livestock items.',
                ]);
            }

            foreach ($items as $index => $item) {
                $livestock = LivestockRecord::query()
                    ->whereKey($item->livestock_id)
                    ->lockForUpdate()
                    ->first();

                if (!$livestock) {
                    throw ValidationException::withMessages([
                        "items.$index.livestock_id" =>
                            'Livestock record no longer exists.',
                    ]);
                }

                if (
                    (string) $livestock->farmer_id !==
                    (string) $farmer->id ||
                    (string) $livestock->municipality_id !==
                    (string) $transaction->municipality_id ||
                    (string) $livestock->barangay_id !==
                    (string) $transaction->barangay_id
                ) {
                    throw ValidationException::withMessages([
                        "items.$index.livestock_id" =>
                            'Livestock ownership or location has changed.',
                    ]);
                }

                if ($livestock->status !== 'available') {
                    throw ValidationException::withMessages([
                        "items.$index.livestock_id" =>
                            'Livestock is no longer available for sale.',
                    ]);
                }

                if (
                    $this->hasActiveTransaction(
                        $livestock->id,
                        $transaction->id
                    )
                ) {
                    throw ValidationException::withMessages([
                        "items.$index.livestock_id" =>
                            'Livestock already belongs to another active transaction.',
                    ]);
                }

                // Reserve livestock until LGU verification.
                $livestock->update([
                    'status' => 'in_transaction',
                ]);

                if ($transaction->auction_schedule_id) {
                    AuctionRegistration::query()
                        ->where('auction_schedule_id', $transaction->auction_schedule_id)
                        ->where('livestock_id', $livestock->id)
                        ->where('farmer_id', $farmer->id)
                        ->first()
                        ?->update([
                            'status' => 'pending_sale_review',
                            'active_livestock_id' => $livestock->id,
                        ]);
                }
            }

            // Skip buyer confirmation.
            // Send directly to LGU Authority verification.
            $transaction->update([
                'status' => 'pending_lgu_verification',
            ]);

            $this->recordStatus(
                $transaction,
                'draft',
                'pending_lgu_verification',
                $encoder,
                'lgu_encoder',
                'Transaction encoded by LGU Encoder and submitted directly for LGU verification.'
            );

            return $transaction->fresh([
                'farmer',
                'items.livestock',
                'items.valuation',
                'statusLogs',
            ]);
        }, 3);
    }


    /*
    |--------------------------------------------------------------------------
    | SHARED DRAFT CREATION
    |--------------------------------------------------------------------------
    */

    private function createTransactionDraft(
        User $actor,
        FarmerProfile $farmer,
        array $data,
        string $actorType
    ): Transaction {
        $this->validateItems($data);

        return DB::transaction(function () use ($actor, $farmer, $data, $actorType) {
            // Revalidate authorization inside the transaction.
            if ($actorType === 'lgu_encoder') {
                $this->assertEncoderCanAccessFarmer(
                    $actor,
                    $farmer->fresh('user')
                );
            } else {
                $this->assertVerifiedFarmer($actor);
            }


            $transaction = Transaction::create([
                'farmer_id' => $farmer->id,
                'buyer_name' => $data['buyer_name'],
                'buyer_phone' => $data['buyer_phone'] ?? null,
                'municipality_id' => $farmer->municipality_id,
                'barangay_id' => $farmer->barangay_id,
                'transaction_date' => $data['transaction_date'] ?? now(),
                'selling_location' => $this->resolveSellingLocation($data),
                'selling_barangay_id' => $data['selling_barangay_id'] ?? null,
                'transaction_type' => $data['transaction_type'] ?? 'private',
                'auction_schedule_id' => $data['auction_schedule_id'] ?? null,
                'status' => 'draft',

                'source' => $actorType === 'lgu_encoder'
                    ? 'lgu_encoder'
                    : 'farmer',

                'buyer_confirmation_method' => $actorType === 'lgu_encoder'
                    ? 'in_person'
                    : null,

                'acknowledgement_reference' => $actorType === 'lgu_encoder'
                    ? ($data['acknowledgement_reference'] ?? null)
                    : null,

                'acknowledgement_notes' => $actorType === 'lgu_encoder'
                    ? ($data['acknowledgement_notes'] ?? null)
                    : null,

                'total_reference_value' => 0,
                'total_selling_price' => 0,
                'encoded_by' => $actor->id,
                'remarks' => $data['remarks'] ?? null,
            ]);

            $totalReference = 0;
            $totalSelling = 0;

            // Stable lock ordering reduces deadlock risk.
            $items = collect($data['items'])
                ->sortBy('livestock_id')
                ->values();

            foreach ($items as $index => $item) {
                $livestock = $this->lockEligibleLivestock(
                    $farmer,
                    $item['livestock_id'],
                    $index
                );

                $valuation = $this->optionalValuation($livestock, $item['valuation_id'] ?? null);
                $sellingPrice = $this->validateSellingPrice($item['actual_selling_price'], $index);
                $purpose = $item['sale_purpose'] ?? (in_array($livestock->sale_purpose, ['slaughter', 'breeding'], true) ? $livestock->sale_purpose : 'slaughter');
                $referenceValue = $valuation ? (float) $valuation->estimated_value : 0.0;
                $weight = $valuation ? (float) $valuation->weight_used_kg : (float) ($livestock->actual_weight_kg ?? 0);
                $difference = $valuation ? round($sellingPrice - $referenceValue, 2) : null;
                $deviation = ($valuation && $referenceValue > 0) ? round(($difference / $referenceValue) * 100, 4) : null;
                $pricePerKg = $weight > 0 ? round($sellingPrice / $weight, 2) : null;

                $transaction->items()->create([
                    'livestock_id' => $livestock->id,
                    'valuation_id' => $valuation?->id,
                    'sale_purpose' => $purpose,
                    'weight_type' => $valuation?->weight_type ?? 'actual',
                    'weight_used_kg' => $weight,
                    'base_price_per_kg' => $valuation?->base_price_per_kg ?? 0,
                    'final_price_per_kg' => $valuation?->final_price_per_kg ?? 0,
                    'reference_value' => $referenceValue,
                    'actual_selling_price' => $sellingPrice,
                    'actual_selling_price_per_kg' => $pricePerKg,
                    'price_difference' => $difference,
                    'percentage_deviation' => $deviation,
                    'valuation_snapshot' => $valuation ? $this->valuationSnapshot($valuation) : ['note' => 'No saved valuation was available at the time of sale recording.'],
                    'calculation_version' => $valuation?->calculation_version ?? 'sale-recording-no-valuation-v1',
                ]);
                $livestock->update(['sale_purpose' => $purpose]);

                $totalReference += $referenceValue;
                $totalSelling += $sellingPrice;
            }

            $transaction->update([
                'total_reference_value' => round(
                    $totalReference,
                    2
                ),
                'total_selling_price' => round(
                    $totalSelling,
                    2
                ),
            ]);

            $this->recordStatus(
                $transaction,
                null,
                'draft',
                $actor,
                $actorType,
                $actorType === 'lgu_encoder'
                ? 'Draft transaction encoded by LGU Encoder.'
                : 'Draft transaction created.'
            );

            $this->notifyTransactionEvent(
                $transaction,
                $farmer,
                'transaction.draft_created',
                'Bag-ong transaction record',
                'A transaction draft has been saved. You can review and continue editing it before submission.'
            );

            return $transaction->load([
                'items.livestock',
                'items.valuation',
                'farmer',
                'statusLogs',
            ]);
        }, 3);
    }

    /*
    |--------------------------------------------------------------------------
    | SHARED TRANSACTION SUBMISSION
    |--------------------------------------------------------------------------
    */


    public function updateFarmerDraft(User $user, string $transactionId, array $data): Transaction
    {
        $farmer = $this->verifiedFarmer($user);
        $this->validateItems($data);

        return DB::transaction(function () use ($farmer, $transactionId, $data) {
            $transaction = Transaction::query()
                ->whereKey($transactionId)
                ->where('farmer_id', $farmer->id)
                ->lockForUpdate()
                ->firstOrFail();

            if ($transaction->status !== 'draft' || $transaction->source !== 'farmer') {
                throw ValidationException::withMessages([
                    'status' => 'Only your own saved farmer drafts can be edited.',
                ]);
            }

            $transaction->update([
                'buyer_name' => $data['buyer_name'],
                'buyer_phone' => $data['buyer_phone'] ?? null,
                'transaction_date' => $data['transaction_date'] ?? $transaction->transaction_date,
                'selling_location' => $this->resolveSellingLocation($data),
                'selling_barangay_id' => $data['selling_barangay_id'] ?? $transaction->selling_barangay_id,
                'remarks' => $data['remarks'] ?? null,
            ]);
            $transaction->items()->delete();

            $totalReference = 0;
            $totalSelling = 0;
            foreach (collect($data['items'])->values() as $index => $item) {
                $livestock = $this->lockEligibleLivestock($farmer, $item['livestock_id'], $index);
                $valuation = $this->optionalValuation($livestock, $item['valuation_id'] ?? null);
                $sellingPrice = $this->validateSellingPrice($item['actual_selling_price'], $index);
                $purpose = $item['sale_purpose'] ?? (in_array($livestock->sale_purpose, ['slaughter', 'breeding'], true) ? $livestock->sale_purpose : 'slaughter');
                $referenceValue = $valuation ? (float) $valuation->estimated_value : 0.0;
                $weight = $valuation ? (float) $valuation->weight_used_kg : (float) ($livestock->actual_weight_kg ?? 0);
                $difference = $valuation ? round($sellingPrice - $referenceValue, 2) : null;
                $deviation = ($valuation && $referenceValue > 0) ? round(($difference / $referenceValue) * 100, 4) : null;
                $transaction->items()->create([
                    'livestock_id' => $livestock->id,
                    'valuation_id' => $valuation?->id,
                    'sale_purpose' => $purpose,
                    'weight_type' => $valuation?->weight_type ?? 'actual',
                    'weight_used_kg' => $weight,
                    'base_price_per_kg' => $valuation?->base_price_per_kg ?? 0,
                    'final_price_per_kg' => $valuation?->final_price_per_kg ?? 0,
                    'reference_value' => $referenceValue,
                    'actual_selling_price' => $sellingPrice,
                    'actual_selling_price_per_kg' => $weight > 0 ? round($sellingPrice / $weight, 2) : null,
                    'price_difference' => $difference,
                    'percentage_deviation' => $deviation,
                    'valuation_snapshot' => $valuation ? $this->valuationSnapshot($valuation) : ['note' => 'No saved valuation was available at the time of sale recording.'],
                    'calculation_version' => $valuation?->calculation_version ?? 'sale-recording-no-valuation-v1',
                ]);
                $livestock->update(['sale_purpose' => $purpose]);
                $totalReference += $referenceValue;
                $totalSelling += $sellingPrice;
            }

            $transaction->update([
                'total_reference_value' => round($totalReference, 2),
                'total_selling_price' => round($totalSelling, 2),
            ]);

            return $transaction->fresh([
                'items.livestock.species',
                'items.valuation',
                'farmer',
                'statusLogs',
            ]);
        }, 3);
    }

    private function submitTransactionDraft(
        User $actor,
        FarmerProfile $farmer,
        string $transactionId,
        BuyerConfirmationService $confirmationService,
        string $actorType
    ): Transaction {
        return DB::transaction(function () use ($actor, $farmer, $transactionId, $confirmationService, $actorType) {
            $transaction = Transaction::query()
                ->whereKey($transactionId)
                ->lockForUpdate()
                ->firstOrFail();

            if (
                (string) $transaction->farmer_id !==
                (string) $farmer->id
            ) {
                abort(403, 'You cannot submit this transaction.');
            }

            if (
                (string) $transaction->encoded_by !==
                (string) $actor->id
            ) {
                abort(403, 'Only the transaction creator may submit it.');
            }

            if ($actorType === 'lgu_encoder') {
                $this->assertEncoder($actor);
                $this->assertEncoderCanAccessFarmer(
                    $actor,
                    $farmer->fresh('user')
                );
            } else {
                $this->assertVerifiedFarmer($actor);
            }

            if ($transaction->status !== 'draft') {
                throw ValidationException::withMessages([
                    'status' => 'Only draft transactions can be submitted.',
                ]);
            }

            $items = $transaction->items()
                ->orderBy('livestock_id')
                ->get();

            if ($items->isEmpty()) {
                throw ValidationException::withMessages([
                    'items' => 'Transaction has no livestock items.',
                ]);
            }

            foreach ($items as $index => $item) {
                $livestock = LivestockRecord::query()
                    ->whereKey($item->livestock_id)
                    ->lockForUpdate()
                    ->first();

                if (!$livestock) {
                    throw ValidationException::withMessages([
                        "items.$index.livestock_id" =>
                            'Livestock no longer exists.',
                    ]);
                }

                if (
                    (string) $livestock->farmer_id !==
                    (string) $farmer->id ||
                    (string) $livestock->municipality_id !==
                    (string) $transaction->municipality_id ||
                    (string) $livestock->barangay_id !==
                    (string) $transaction->barangay_id
                ) {
                    throw ValidationException::withMessages([
                        "items.$index.livestock_id" =>
                            'Livestock ownership or location has changed.',
                    ]);
                }

                if ($livestock->status !== 'available') {
                    throw ValidationException::withMessages([
                        "items.$index.livestock_id" =>
                            'Livestock is no longer available.',
                    ]);
                }

                if (
                    $this->hasActiveTransaction(
                        $livestock->id,
                        $transaction->id
                    )
                ) {
                    throw ValidationException::withMessages([
                        "items.$index.livestock_id" =>
                            'Livestock belongs to another active transaction.',
                    ]);
                }

                $livestock->update([
                    'status' => 'in_transaction',
                ]);

                // Keep auction participation synchronized with the transaction.
                // A post-auction farmer response is linked to its specific event;
                // a private sale reserves any currently active auction registration.
                $registrationQuery = AuctionRegistration::query()
                    ->where('livestock_id', $livestock->id)
                    ->where('farmer_id', $farmer->id)
                    ->lockForUpdate();

                if ($transaction->auction_schedule_id) {
                    $registrationQuery->where('auction_schedule_id', $transaction->auction_schedule_id);
                } else {
                    $registrationQuery->where('active_livestock_id', $livestock->id)
                        ->where('status', 'registered');
                }

                $registrationQuery->get()->each(function (AuctionRegistration $registration) use ($livestock) {
                    $registration->update([
                        'status' => 'pending_sale_review',
                        'active_livestock_id' => $livestock->id,
                        'remarks' => trim(($registration->remarks ? $registration->remarks . "\n" : '') . 'Livestock is reserved by a farmer-reported transaction awaiting LGU Authority verification.'),
                    ]);
                });
            }

            $transaction->update([
                'status' => 'pending_lgu_verification',
            ]);

            $this->recordStatus(
                $transaction,
                'draft',
                'pending_lgu_verification',
                $actor,
                $actorType,
                'Submitted directly for LGU Authority verification.'
            );

            $this->notifyTransactionEvent(
                $transaction,
                $farmer,
                'transaction.submitted',
                'Na-submit na ang transaction',
                'Your sale has been submitted to the Municipal Agriculture Office for verification.'
            );

            return $transaction->fresh([
                'items',
                'buyerConfirmations',
                'statusLogs',
            ]);
        }, 3);
    }

    /*
    |--------------------------------------------------------------------------
    | FARMER & ENCODER AUTHORIZATION
    |--------------------------------------------------------------------------
    */

    private function notifyTransactionEvent(Transaction $transaction, FarmerProfile $farmer, string $event, string $title, string $message): void
    {
        $farmer->user?->notify(new SystemAlertNotification(
            $event, $title, $message, (string) $transaction->municipality_id,
            'transaction', (string) $transaction->id
        ));

        $officers = User::query()
            ->where('status', 'active')
            ->whereHas('roles', fn ($q) => $q->whereIn('slug', ['lgu_encoder', 'lgu_authority']))
            ->whereHas('lguOfficerProfile', fn ($q) => $q->where('municipality_id', $transaction->municipality_id))
            ->get();
        foreach ($officers as $officer) {
            $officer->notify(new SystemAlertNotification(
                $event, $title, 'A farmer transaction has been recorded. Review it in the transaction workspace.',
                (string) $transaction->municipality_id, 'transaction', (string) $transaction->id
            ));
        }
    }

    private function verifiedFarmer(User $user): FarmerProfile
    {
        $this->assertVerifiedFarmer($user);

        return $user->farmerProfile;
    }

    private function assertVerifiedFarmer(User $user): void
    {
        if (
            !$user->farmerProfile ||
            $user->verification_status !== 'verified'
        ) {
            throw ValidationException::withMessages([
                'farmer' => 'A verified farmer profile is required.',
            ]);
        }
    }

    private function assertEncoder(User $user): void
    {
        abort_unless(
            $user->roles()
                ->where(function ($query) {
                    $query->whereIn('slug', ['lgu_encoder', 'lgu-encoder', 'encoder'])
                        ->orWhereRaw('LOWER(name) = ?', ['lgu encoder']);
                })
                ->exists(),
            403,
            'Only LGU Encoders may encode transactions.'
        );
    }

    private function assertEncoderCanAccessFarmer(
        User $encoder,
        FarmerProfile $farmer
    ): void {
        $this->assertEncoder($encoder);

        $municipalityId =
            $encoder->lguOfficerProfile?->municipality_id;

        abort_unless(
            $municipalityId &&
            (string) $municipalityId ===
            (string) $farmer->municipality_id,
            403,
            'Farmer is outside your assigned municipality.'
        );

        if (
            !$farmer->user ||
            $farmer->user->verification_status !== 'verified'
        ) {
            throw ValidationException::withMessages([
                'farmer_id' =>
                    'The selected farmer must be verified.',
            ]);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | LIVESTOCK VALIDATION
    |--------------------------------------------------------------------------
    */

    private function validateItems(array $data): void
    {
        if (
            empty($data['items']) ||
            !is_array($data['items'])
        ) {
            throw ValidationException::withMessages([
                'items' => 'At least one livestock item is required.',
            ]);
        }

        $ids = array_column(
            $data['items'],
            'livestock_id'
        );

        if (count($ids) !== count(array_unique($ids))) {
            throw ValidationException::withMessages([
                'items' => 'Duplicate livestock items are not allowed.',
            ]);
        }
    }

    private function lockEligibleLivestock(
        FarmerProfile $farmer,
        string $livestockId,
        int $index
    ): LivestockRecord {
        $livestock = LivestockRecord::query()
            ->whereKey($livestockId)
            ->lockForUpdate()
            ->first();

        if (!$livestock) {
            throw ValidationException::withMessages([
                "items.$index.livestock_id" =>
                    'Livestock record not found.',
            ]);
        }

        if (
            (string) $livestock->farmer_id !==
            (string) $farmer->id
        ) {
            throw ValidationException::withMessages([
                "items.$index.livestock_id" =>
                    'This livestock does not belong to the farmer.',
            ]);
        }

        if (
            (string) $livestock->municipality_id !==
            (string) $farmer->municipality_id ||
            (string) $livestock->barangay_id !==
            (string) $farmer->barangay_id
        ) {
            throw ValidationException::withMessages([
                "items.$index.livestock_id" =>
                    'Livestock location does not match the farmer profile.',
            ]);
        }

        if ($livestock->status !== 'available') {
            throw ValidationException::withMessages([
                "items.$index.livestock_id" =>
                    'Livestock is not available for sale.',
            ]);
        }

        if ($this->hasActiveTransaction($livestock->id)) {
            throw ValidationException::withMessages([
                "items.$index.livestock_id" =>
                    'Livestock already belongs to an active or completed transaction.',
            ]);
        }

        return $livestock;
    }

    private function hasActiveTransaction(
        string $livestockId,
        ?string $exceptTransactionId = null
    ): bool {
        return DB::table('transaction_items')
            ->join(
                'transactions',
                'transactions.id',
                '=',
                'transaction_items.transaction_id'
            )
            ->where(
                'transaction_items.livestock_id',
                $livestockId
            )
            ->whereIn(
                'transactions.status',
                self::ACTIVE_STATUSES
            )
            ->when(
                $exceptTransactionId,
                fn($query) => $query->where(
                    'transactions.id',
                    '!=',
                    $exceptTransactionId
                )
            )
            ->exists();
    }

    /*
    |--------------------------------------------------------------------------
    | VALUATION & SELLING PRICE
    |--------------------------------------------------------------------------
    */

    private function optionalValuation(LivestockRecord $livestock, ?string $valuationId): ?Valuation
    {
        if ($valuationId) {
            return $this->getValidValuation($livestock, $valuationId, 0);
        }

        return Valuation::query()
            ->where('livestock_id', $livestock->id)
            ->whereNotNull('estimated_value')
            ->where('estimated_value', '>', 0)
            ->where('weight_used_kg', '>', 0)
            ->latest('created_at')
            ->first();
    }

    private function getValidValuation(
        LivestockRecord $livestock,
        string $valuationId,
        int $index
    ): Valuation {
        $valuation = Valuation::query()
            ->whereKey($valuationId)
            ->where('livestock_id', $livestock->id)
            ->first();

        if (!$valuation) {
            throw ValidationException::withMessages([
                "items.$index.valuation_id" =>
                    'A valid valuation for this livestock is required.',
            ]);
        }

        if (
            !is_finite((float) $valuation->estimated_value) ||
            (float) $valuation->estimated_value <= 0
        ) {
            throw ValidationException::withMessages([
                "items.$index.valuation_id" =>
                    'The selected valuation has an invalid reference value.',
            ]);
        }

        if (
            !is_finite((float) $valuation->weight_used_kg) ||
            (float) $valuation->weight_used_kg <= 0
        ) {
            throw ValidationException::withMessages([
                "items.$index.valuation_id" =>
                    'The selected valuation has an invalid weight.',
            ]);
        }

        return $valuation;
    }

    private function validateSellingPrice(
        mixed $price,
        int $index
    ): float {
        if (
            !is_numeric($price) ||
            !is_finite((float) $price) ||
            (float) $price <= 0
        ) {
            throw ValidationException::withMessages([
                "items.$index.actual_selling_price" =>
                    'Selling price must be greater than zero.',
            ]);
        }

        return round((float) $price, 2);
    }

    private function valuationSnapshot(
        Valuation $valuation
    ): array {
        return [
            'valuation_id' => $valuation->id,
            'calculation_version' =>
                $valuation->calculation_version,
            'calculation_snapshot' =>
                $valuation->calculation_snapshot,
            'adjustment_breakdown' =>
                $valuation->adjustment_breakdown,
            'weight_type' => $valuation->weight_type,
            'weight_used_kg' => $valuation->weight_used_kg,
            'base_price_per_kg' =>
                $valuation->base_price_per_kg,
            'final_price_per_kg' =>
                $valuation->final_price_per_kg,
            'estimated_value' =>
                $valuation->estimated_value,
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | TRANSACTION STATUS LOGGING
    |--------------------------------------------------------------------------
    */

    private function recordStatus(
        Transaction $transaction,
        ?string $from,
        string $to,
        User $actor,
        string $actorType,
        string $remarks
    ): void {
        $transaction->statusLogs()->create([
            'from_status' => $from,
            'to_status' => $to,
            'actor_type' => $actorType,
            'actor_user_id' => $actor->id,
            'remarks' => $remarks,
        ]);
    }
    private function resolveSellingLocation(array $data): ?string
    {
        $typedLocation = trim((string) ($data['selling_location'] ?? ''));
        if ($typedLocation !== '') return $typedLocation;

        $barangayId = $data['selling_barangay_id'] ?? null;
        if (!$barangayId) return null;

        return Barangay::query()->whereKey($barangayId)->value('name');
    }

}
